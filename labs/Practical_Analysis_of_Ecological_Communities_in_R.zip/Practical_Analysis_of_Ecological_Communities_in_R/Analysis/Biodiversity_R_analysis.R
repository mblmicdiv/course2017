# Looking at Biodiversity data

library(vegan)

# Read in the dataset
data0 <- read.delim('LTER_Biodiversity_prop_no-singletons_t.txt')

data = data0[,6:7135]

groups = data0[,1:5]

# Test for significant differences 
# use a perMANOVA

adonis(data0 ~ Treatment, data=groups)
# turns out to be significant

adonis(data0 ~ Crop, data=groups)
# significant

adonis(data0 ~ Species_num, data=groups)
# significant

# Look at them together
adonis(data0 ~ Crop + Species_num, data=groups)

Do an MDS analysis

x <- metaMDS(data)

library(ggplot2)

qplot(x$point[,1], x$points[,2], color=groups$Treatment, size=3)

y <- stressplot(x)

# Try a PCA

pca <- rda(data)

qplot(pca$CA$u[,1], pca$CA$u[,2], color=groups$Treatment, size=3)

# Definitely looks better with NMS

# Do a Wittaker test to see if you should use an NMS or a PCA
# Suggest less than 1 is OK for PCA, but more should be NMS

ncol(data)/mean(specnumber(data)) - 1

# We get 1.01
# but because we have so many descriptors (OTUs) NMS is probably the better choice

# Turn it into presence/absence

binary <- vegdist(data, binary=T)

z <- metaMDS(binary)

